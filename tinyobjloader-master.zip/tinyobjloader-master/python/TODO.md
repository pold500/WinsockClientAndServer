* PBR material
* Define index_t struct
* Python 2.7 binding
